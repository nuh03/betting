# Voetbal AI Streamlit App

Een tool om value bets in voetbal te vinden op basis van AI-voorspellingen en bookmaker odds.

## Gebruik

1. Upload deze repo naar GitHub
2. Deploy via https://streamlit.io/cloud
3. Hoofdbestand: `app.py`
